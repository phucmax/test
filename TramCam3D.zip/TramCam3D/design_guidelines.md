# Design Guidelines: Mental Health Assessment Platform

## Design Approach

**Selected Approach:** Reference-Based with Health & Wellness Focus

Drawing inspiration from leading mental health and wellness platforms (Calm, Headspace, BetterHelp) combined with modern 3D web experiences. The design must create a safe, supportive atmosphere while incorporating engaging 3D elements that don't overwhelm sensitive users.

**Core Principles:**
- Calming and approachable aesthetic
- Progressive disclosure to prevent overwhelm
- Clear visual hierarchy for easy navigation
- Subtle 3D elements that enhance without distracting
- Trustworthy, professional presentation

---

## Typography System

**Font Families:**
- Primary: 'Inter' or 'DM Sans' (Google Fonts) - clean, modern, highly legible
- Accent: 'Quicksand' (Google Fonts) - soft, friendly for headings

**Typography Scale:**
- Hero Headlines: text-5xl md:text-6xl lg:text-7xl, font-bold
- Section Headers: text-3xl md:text-4xl, font-semibold
- Question Text: text-xl md:text-2xl, font-medium
- Body Text: text-base md:text-lg, font-normal
- Supporting Text: text-sm md:text-base

---

## Layout System

**Spacing Primitives:** Consistent use of Tailwind units: 4, 6, 8, 12, 16, 20, 24
- Component padding: p-6 md:p-8
- Section spacing: py-16 md:py-20 lg:py-24
- Card gaps: gap-6 md:gap-8
- Container max-width: max-w-4xl for quiz content, max-w-6xl for landing sections

**Grid System:**
- Quiz questions: Single column, centered (max-w-3xl)
- Landing features: grid-cols-1 md:grid-cols-3
- Results breakdown: grid-cols-1 md:grid-cols-2

---

## Page Structure & Components

### Landing Page (5-6 Sections)

**Hero Section (80vh):**
- Centered content with 3D animated background (Three.js particle system or gradient sphere)
- Large headline introducing the assessment purpose
- Subheadline explaining privacy and confidentiality
- Primary CTA button: "Bắt Đầu Đánh Giá" (Start Assessment)
- Trust indicators below CTA: "Hoàn toàn miễn phí • Kết quả ngay lập tức • Bảo mật thông tin"

**How It Works Section:**
- 3-column grid on desktop, stacked on mobile
- Step cards with icons (numbers 1, 2, 3) using Heroicons
- Each card: Icon, heading, brief description
- Content: Step 1 - Answer questions, Step 2 - Receive results, Step 3 - Get personalized advice

**Why This Matters Section:**
- Two-column layout (text + supportive illustration/abstract 3D element)
- Statistics about mental health in Vietnam
- Emphasis on early detection and support

**Privacy & Confidentiality:**
- Single column, centered content (max-w-3xl)
- Clear assurances about data handling
- Icons from Heroicons for: No data storage, Anonymous, Secure

**CTA Section:**
- Centered, focused design
- Repeated primary action button
- Supporting text: "5-7 phút • 18 câu hỏi • Kết quả tức thì"

**Footer:**
- Mental health resources and hotlines in Vietnam
- Disclaimer about professional help
- Contact information

### Assessment Flow (Quiz Pages)

**Progress Indicator:**
- Fixed top bar with progress percentage and current question number
- Subtle 3D animated progress bar

**Question Container:**
- Centered card layout (max-w-3xl)
- Large, clear question text
- Generous spacing between question and options (space-y-6)

**Answer Options:**
- Vertical stack of radio button cards
- Each option as a full-width card with hover states
- 4-5 answer choices per question (Likert scale format)
- Options: "Không bao giờ", "Thỉnh thoảng", "Thường xuyên", "Hầu như lúc nào", "Luôn luôn"
- Large click targets (min-h-16)

**Navigation:**
- Bottom buttons: "Quay lại" (Back) and "Tiếp theo" (Next)
- Next button only active after selection

### Results Page

**Results Header:**
- Centered score presentation with animated number counter
- Severity level badge/indicator
- Brief interpretation headline

**Detailed Breakdown:**
- 2-column grid (desktop) with category scores
- Animated progress bars or circular charts
- Categories: Mood, Energy, Sleep, Concentration, etc.

**Recommendations Section:**
- Prominent card with personalized advice based on severity
- For severe cases: Urgent support resources highlighted
- Action items list with clear next steps
- Calming 3D background element

**Resources Section:**
- Cards with Vietnam-specific mental health resources
- Hotlines, online counseling, in-person services
- Emergency contacts prominently displayed for severe cases

**Comfort Messages:**
- Warm, supportive messaging throughout
- Avoid clinical/cold language
- Emphasis on hope and available support

---

## Component Library

**Buttons:**
- Primary: Large, rounded (rounded-xl), py-4 px-8
- Secondary: Outlined variant, same sizing
- Ghost: Text-only for less important actions

**Cards:**
- Elevated appearance with generous padding (p-8)
- Rounded corners (rounded-2xl)
- Option cards: Interactive, clear selected state

**Input Elements:**
- Radio buttons: Custom styled as cards
- Visual feedback on selection (scale, border emphasis)

**Modals/Overlays:**
- Info modals for question clarification
- Privacy policy overlay
- Results share dialog

---

## 3D Animation Strategy

**Landing Page:**
- Hero: Animated particle system or morphing gradient sphere (Three.js)
- Subtle parallax scrolling effects
- Floating elements with gentle motion

**Quiz Flow:**
- Minimal 3D - subtle background gradient animations
- Question transitions: Smooth fade and slight 3D card flip
- Progress bar with dimensional depth

**Results Page:**
- Animated data visualization
- Gentle floating background elements
- Confetti or positive animation for completion (non-severe cases)

**Performance:**
- Lazy load 3D elements
- Reduce motion for users with preferences
- Mobile-optimized simplified animations

---

## Accessibility & UX

- High contrast text throughout
- Clear focus indicators for keyboard navigation
- Screen reader friendly labels in Vietnamese
- Skip to content link
- Reduced motion alternative
- Touch-friendly hit areas (min 44x44px)
- Clear error states and validation

---

## Images

**Hero Section:** Abstract, calming 3D rendered image or soft gradient background (can be generated with Three.js or static image). Showing peaceful, hopeful atmosphere - think soft clouds, gentle light, serene abstract shapes.

**How It Works Section:** Custom icons or simple illustrations for each step. Keep minimal and supportive.

**Results Page:** Depending on severity, include appropriate supportive imagery. For severe results, include an image suggesting professional support/human connection.

**No large photographic hero image required** - 3D animations serve as primary visual interest.

---

## Responsive Behavior

- Mobile-first design approach
- Quiz cards full-width on mobile with adequate padding
- Stacked layouts on mobile, grid on tablet/desktop
- Reduced 3D complexity on mobile devices
- Simplified animations for performance
- Touch-optimized button sizes