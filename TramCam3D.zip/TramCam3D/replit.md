# Website Đánh Giá Sức Khỏe Tâm Lý

## Tổng Quan
Website kiểm tra trầm cảm hoàn toàn bằng tiếng Việt với giao diện 3D animation đẹp mắt. Người dùng trả lời 18 câu hỏi và nhận kết quả phân tích chi tiết kèm lời khuyên cá nhân hóa.

## Mục Tiêu
- Cung cấp công cụ đánh giá sức khỏe tâm lý miễn phí và dễ tiếp cận
- Giúp người dùng nhận biết sớm các dấu hiệu trầm cảm
- Đưa ra lời khuyên và hướng dẫn phù hợp với từng mức độ
- Tạo trải nghiệm thân thiện, an toàn và bảo mật

## Tính Năng Chính

### 1. Landing Page
- Hero section với 3D particle animation (Three.js)
- Giới thiệu về bài test và lợi ích
- Thông tin về quy trình và bảo mật
- Tài nguyên hỗ trợ và đường dây nóng

### 2. Quiz Flow
- 18 câu hỏi đánh giá toàn diện
- Progress bar theo dõi tiến trình
- Animated question cards với 5 mức độ trả lời
- Smooth transitions giữa các câu hỏi
- Nút quay lại và tiếp theo

### 3. Results Page
- Hiển thị điểm số và mức độ trầm cảm (minimal, mild, moderate, severe, very-severe)
- Biểu đồ phân tích chi tiết theo từng lĩnh vực
- Lời khuyên cá nhân hóa dựa trên kết quả
- Danh sách recommendations cụ thể
- Cảnh báo khẩn cấp cho trường hợp nghiêm trọng
- 3D background với floating elements

### 4. Dark/Light Mode
- Theme toggle với smooth transition
- Tự động lưu preference vào localStorage
- Màu sắc tối ưu cho cả hai chế độ

## Công Nghệ

### Frontend
- **React + TypeScript** - UI framework
- **Wouter** - Client-side routing
- **Three.js** - 3D graphics và animations
- **Recharts** - Data visualization
- **Tailwind CSS** - Styling
- **Shadcn UI** - Component library
- **Framer Motion** - Animations (có sẵn)

### Backend
- **Express.js** - Server framework
- **In-memory storage** - Data persistence
- **Zod** - Schema validation

### Design System
- **Fonts**: Inter (primary), Quicksand (accent)
- **Colors**: Calming blue palette với subtle gradients
- **Spacing**: Consistent 4px grid system
- **Components**: Shadcn UI components với custom styling

## Cấu Trúc Dữ Liệu

### Questions
18 câu hỏi được phân loại theo categories:
- mood, sleep, energy, appetite
- self-esteem, concentration, psychomotor
- suicidal, anxiety, guilt
- daily-function, social, hopelessness
- physical, emotional, irritability, numbness

### Answer Options
5 mức độ trả lời (0-4 điểm):
- Không bao giờ (0)
- Thỉnh thoảng (1)
- Thường xuyên (2)
- Hầu như lúc nào (3)
- Luôn luôn (4)

### Severity Levels
Phân loại dựa trên % điểm:
- **Minimal** (<20%): Tối thiểu
- **Mild** (20-40%): Nhẹ
- **Moderate** (40-60%): Trung bình
- **Severe** (60-80%): Nặng
- **Very Severe** (>80%): Rất nặng

## User Flow
1. Người dùng vào trang chủ → Đọc thông tin → Nhấn "Bắt Đầu Đánh Giá"
2. Trả lời 18 câu hỏi với progress tracking
3. Xem kết quả chi tiết với biểu đồ và lời khuyên
4. Có thể làm lại test hoặc về trang chủ

## Tính Năng Bảo Mật & Riêng Tư
- Không lưu trữ thông tin cá nhân
- Không yêu cầu đăng nhập
- Kết quả chỉ lưu trong localStorage của trình duyệt
- Hoàn toàn ẩn danh

## Design Principles
- **Calming & Approachable**: Màu sắc nhẹ nhàng, không gây áp lực
- **Clear Hierarchy**: Typography và spacing rõ ràng
- **Subtle 3D**: Animations tăng thêm visual interest nhưng không làm phân tâm
- **Trustworthy**: Giao diện chuyên nghiệp, đáng tin cậy
- **Responsive**: Hoạt động tốt trên mọi thiết bị

## Upcoming Features
- Tích hợp AI để cá nhân hóa lời khuyên chi tiết hơn
- Lưu lịch sử test để theo dõi tiến triển
- Thêm các bài test khác: lo âu, stress, burnout
- Tài nguyên hỗ trợ: bài viết, video, hotlines Việt Nam
- Chia sẻ kết quả với chuyên gia (mã hóa)

## Lưu Ý Quan Trọng
Website này chỉ mang tính chất tham khảo và không thay thế cho chẩn đoán y tế chuyên nghiệp. Luôn khuyến khích người dùng tìm kiếm sự hỗ trợ từ chuyên gia khi cần thiết.

## Development Status
✅ Phase 1: Schema & Frontend Complete
- Data models defined
- Design tokens configured
- All React components built
- 3D animations implemented
- Dark/Light mode working

🔄 Phase 2: Backend Implementation (In Progress)
- API endpoints
- Storage interface
- Business logic

⏳ Phase 3: Integration & Testing
- Connect frontend to backend
- Add error handling
- Test all user journeys
