import { type Answer, type AnalyzedResult, type SeverityLevel, type CategoryScore, questions } from "@shared/schema";

export function calculateResults(answers: Answer[]): AnalyzedResult {
  const totalScore = answers.reduce((sum, answer) => sum + answer.value, 0);
  const maxScore = questions.length * 4;
  const percentage = (totalScore / maxScore) * 100;

  const severityLevel: SeverityLevel = getSeverityLevel(percentage);
  
  const categoryScores = calculateCategoryScores(answers);
  
  const { advice, recommendations } = getAdviceAndRecommendations(severityLevel, categoryScores);
  
  const urgentHelp = severityLevel === "severe" || severityLevel === "very-severe" || 
    answers.some(a => a.questionId === 9 && a.value >= 2);

  return {
    totalScore,
    maxScore,
    percentage,
    severityLevel,
    categoryScores,
    advice,
    recommendations,
    urgentHelp
  };
}

function getSeverityLevel(percentage: number): SeverityLevel {
  if (percentage < 20) return "minimal";
  if (percentage < 40) return "mild";
  if (percentage < 60) return "moderate";
  if (percentage < 80) return "severe";
  return "very-severe";
}

function calculateCategoryScores(answers: Answer[]): CategoryScore[] {
  const categoryMap = new Map<string, { score: number; count: number }>();

  answers.forEach(answer => {
    const question = questions.find(q => q.id === answer.questionId);
    if (!question) return;

    const current = categoryMap.get(question.category) || { score: 0, count: 0 };
    categoryMap.set(question.category, {
      score: current.score + answer.value,
      count: current.count + 1
    });
  });

  const categoryLabels: Record<string, string> = {
    mood: "Tâm trạng",
    sleep: "Giấc ngủ",
    energy: "Năng lượng",
    appetite: "Cảm giác ngon miệng",
    "self-esteem": "Lòng tự trọng",
    concentration: "Tập trung",
    psychomotor: "Vận động tâm lý",
    suicidal: "Suy nghĩ tiêu cực",
    anxiety: "Lo âu",
    guilt: "Cảm giác tội lỗi",
    "daily-function": "Hoạt động hàng ngày",
    social: "Giao tiếp xã hội",
    hopelessness: "Cảm giác vô vọng",
    physical: "Thể chất",
    emotional: "Cảm xúc",
    irritability: "Cáu kỉnh",
    numbness: "Vô cảm"
  };

  return Array.from(categoryMap.entries())
    .map(([category, data]) => ({
      category: categoryLabels[category] || category,
      score: data.score,
      maxScore: data.count * 4,
      percentage: (data.score / (data.count * 4)) * 100
    }))
    .sort((a, b) => b.percentage - a.percentage)
    .slice(0, 6);
}

function getAdviceAndRecommendations(
  severityLevel: SeverityLevel,
  categoryScores: CategoryScore[]
): { advice: string; recommendations: string[] } {
  const adviceMap: Record<SeverityLevel, string> = {
    minimal: "Kết quả cho thấy bạn đang có tâm trạng khá tốt! Tuy nhiên, vẫn nên chú ý chăm sóc sức khỏe tinh thần của mình.",
    mild: "Bạn có thể đang trải qua một số dấu hiệu nhẹ của trầm cảm. Đây là lúc tốt để bắt đầu chăm sóc bản thân nhiều hơn.",
    moderate: "Kết quả cho thấy bạn có các dấu hiệu trầm cảm ở mức độ trung bình. Rất khuyến khích bạn tìm kiếm sự hỗ trợ từ chuyên gia tâm lý.",
    severe: "Bạn đang có các dấu hiệu trầm cảm nghiêm trọng. Điều quan trọng là bạn nên liên hệ với chuyên gia sức khỏe tâm thần càng sớm càng tốt.",
    "very-severe": "Kết quả cho thấy bạn đang gặp khó khăn rất lớn. Vui lòng liên hệ ngay với chuyên gia hoặc đường dây nóng hỗ trợ tâm lý. Bạn không đơn độc và có nhiều người sẵn sàng giúp đỡ."
  };

  const recommendationsMap: Record<SeverityLevel, string[]> = {
    minimal: [
      "Duy trì lối sống lành mạnh với chế độ ăn cân bằng và tập thể dục đều đặn",
      "Dành thời gian cho những hoạt động yêu thích",
      "Giữ kết nối với gia đình và bạn bè",
      "Thực hành chánh niệm và thiền định",
      "Ngủ đủ 7-8 tiếng mỗi đêm"
    ],
    mild: [
      "Cân nhắc gặp tư vấn viên tâm lý để được hỗ trợ",
      "Tăng cường hoạt động thể chất, ít nhất 30 phút mỗi ngày",
      "Chia sẻ cảm xúc với người thân tin tưởng",
      "Giảm stress bằng yoga, thiền, hoặc các kỹ thuật thư giãn",
      "Hạn chế rượu bia và các chất kích thích",
      "Tham gia các hoạt động xã hội và sở thích cá nhân"
    ],
    moderate: [
      "Gặp chuyên gia tâm lý hoặc bác sĩ tâm thần để được tư vấn chuyên môn",
      "Cân nhắc liệu pháp tâm lý như CBT (Liệu pháp nhận thức hành vi)",
      "Tham gia nhóm hỗ trợ về sức khỏe tâm lý",
      "Duy trì nhật ký cảm xúc để theo dõi tâm trạng",
      "Tạo thói quen sinh hoạt đều đặn",
      "Tránh tự cô lập, giữ liên lạc với người thân"
    ],
    severe: [
      "LÊN HỆ NGAY với chuyên gia sức khỏe tâm thần hoặc bác sĩ",
      "Gọi đường dây nóng hỗ trợ tâm lý: 1800 599 916",
      "Đừng tự điều trị, cần có sự theo dõi y tế chuyên nghiệp",
      "Thông báo cho người thân để được hỗ trợ",
      "Cân nhắc điều trị kết hợp thuốc và tâm lý trị liệu",
      "Tránh ở một mình trong thời gian dài"
    ],
    "very-severe": [
      "KHẨN CẤP: Liên hệ ngay với dịch vụ y tế hoặc đường dây nóng",
      "Đường dây nóng 24/7: 1800 599 916 hoặc 028 3812 3456",
      "Đi bệnh viện hoặc phòng khám tâm thần ngay lập tức",
      "Không được ở một mình, hãy có người thân bên cạnh",
      "Hãy nhớ: bạn không đơn độc, nhiều người muốn giúp đỡ bạn",
      "Tình trạng này có thể được điều trị, đừng mất hy vọng"
    ]
  };

  const topIssues = categoryScores.slice(0, 3).filter(cat => cat.percentage > 50);
  let customAdvice = "";
  
  if (topIssues.length > 0) {
    const issues = topIssues.map(cat => cat.category.toLowerCase()).join(", ");
    customAdvice = ` Các vấn đề chính của bạn dường như liên quan đến ${issues}.`;
  }

  return {
    advice: adviceMap[severityLevel] + customAdvice,
    recommendations: recommendationsMap[severityLevel]
  };
}

export function getSeverityLevelLabel(level: SeverityLevel): string {
  const labels: Record<SeverityLevel, string> = {
    minimal: "Tối thiểu",
    mild: "Nhẹ",
    moderate: "Trung bình",
    severe: "Nặng",
    "very-severe": "Rất nặng"
  };
  return labels[level];
}

export function getSeverityLevelColor(level: SeverityLevel): string {
  const colors: Record<SeverityLevel, string> = {
    minimal: "text-green-600 dark:text-green-400",
    mild: "text-yellow-600 dark:text-yellow-400",
    moderate: "text-orange-600 dark:text-orange-400",
    severe: "text-red-600 dark:text-red-400",
    "very-severe": "text-red-700 dark:text-red-500"
  };
  return colors[level];
}

export function getSeverityBadgeVariant(level: SeverityLevel): "default" | "secondary" | "destructive" {
  if (level === "minimal") return "secondary";
  if (level === "mild") return "default";
  return "destructive";
}
