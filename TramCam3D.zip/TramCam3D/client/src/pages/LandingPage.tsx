import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThreeBackground } from "@/components/ThreeBackground";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Heart, Shield, Clock, TrendingUp, Phone, AlertCircle } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <ThreeBackground />
      
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-accent font-semibold text-foreground">
            Sức Khỏe Tâm Lý
          </h1>
          <ThemeToggle />
        </div>
      </header>

      <section className="relative min-h-[85vh] flex items-center justify-center px-4 pt-20">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent pointer-events-none" />
        
        <div className="container mx-auto max-w-4xl text-center space-y-8 relative z-10">
          <div className="space-y-6">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold font-accent text-foreground leading-tight">
              Đánh Giá Sức Khỏe<br />Tâm Lý Của Bạn
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Bài kiểm tra trầm cảm miễn phí, kết quả ngay lập tức với lời khuyên cá nhân hóa. 
              Hoàn toàn bảo mật và ẩn danh.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link href="/quiz">
              <Button size="lg" className="text-lg px-8 py-6 rounded-xl" data-testid="button-hero-start">
                Bắt Đầu Đánh Giá
              </Button>
            </Link>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 pt-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>5-7 phút</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span>18 câu hỏi</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span>Bảo mật thông tin</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-card/30">
        <div className="container mx-auto max-w-6xl">
          <h3 className="text-3xl md:text-4xl font-semibold font-accent text-center mb-12 text-foreground">
            Cách Thức Hoạt Động
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="hover-elevate transition-all duration-300" data-testid="card-step-1">
              <CardContent className="p-8 space-y-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-3xl font-bold text-primary">1</span>
                </div>
                <h4 className="text-xl font-semibold text-card-foreground">Trả Lời Câu Hỏi</h4>
                <p className="text-muted-foreground">
                  Hoàn thành 18 câu hỏi về cảm xúc và trạng thái tâm lý của bạn trong thời gian gần đây.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-step-2">
              <CardContent className="p-8 space-y-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-3xl font-bold text-primary">2</span>
                </div>
                <h4 className="text-xl font-semibold text-card-foreground">Nhận Kết Quả</h4>
                <p className="text-muted-foreground">
                  Nhận được phân tích chi tiết về mức độ trầm cảm và các chỉ số sức khỏe tâm lý.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate transition-all duration-300" data-testid="card-step-3">
              <CardContent className="p-8 space-y-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-3xl font-bold text-primary">3</span>
                </div>
                <h4 className="text-xl font-semibold text-card-foreground">Nhận Lời Khuyên</h4>
                <p className="text-muted-foreground">
                  Nhận lời khuyên cá nhân hóa và gợi ý hành động phù hợp với tình trạng của bạn.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h3 className="text-3xl md:text-4xl font-semibold font-accent text-foreground">
                Tại Sao Điều Này Quan Trọng?
              </h3>
              <p className="text-lg text-muted-foreground">
                Sức khỏe tâm lý là một phần quan trọng của sức khỏe tổng thể. Việc nhận biết sớm 
                các dấu hiệu trầm cảm giúp bạn có thể tìm kiếm sự hỗ trợ kịp thời.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <Heart className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <span className="text-muted-foreground">
                    Theo WHO, khoảng 280 triệu người trên thế giới đang sống với trầm cảm
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <TrendingUp className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <span className="text-muted-foreground">
                    Phát hiện sớm giúp cải thiện khả năng điều trị và phục hồi
                  </span>
                </li>
              </ul>
            </div>

            <Card data-testid="card-privacy">
              <CardContent className="p-8 space-y-4">
                <Shield className="h-12 w-12 text-primary" />
                <h4 className="text-xl font-semibold text-card-foreground">Bảo Mật & Riêng Tư</h4>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>Không lưu trữ dữ liệu cá nhân</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>Hoàn toàn ẩn danh</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>Kết quả chỉ hiển thị cho bạn</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-primary/5">
        <div className="container mx-auto max-w-3xl text-center space-y-8">
          <h3 className="text-3xl md:text-4xl font-semibold font-accent text-foreground">
            Sẵn Sàng Bắt Đầu?
          </h3>
          <p className="text-lg text-muted-foreground">
            Chỉ mất 5-7 phút để hoàn thành bài đánh giá và nhận kết quả ngay lập tức
          </p>
          <Link href="/quiz">
            <Button size="lg" className="text-lg px-8 py-6 rounded-xl" data-testid="button-cta-start">
              Bắt Đầu Ngay
            </Button>
          </Link>
        </div>
      </section>

      <footer className="py-12 px-4 border-t bg-card/30">
        <div className="container mx-auto max-w-6xl">
          <div className="space-y-8">
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <AlertCircle className="h-6 w-6 text-destructive flex-shrink-0 mt-1" />
                <div className="space-y-2">
                  <h4 className="font-semibold text-destructive">Lưu Ý Quan Trọng</h4>
                  <p className="text-sm text-muted-foreground">
                    Bài kiểm tra này chỉ mang tính chất tham khảo và không thay thế cho chẩn đoán 
                    y tế chuyên nghiệp. Nếu bạn đang gặp khó khăn về sức khỏe tâm lý, vui lòng 
                    liên hệ với chuyên gia hoặc cơ sở y tế.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card data-testid="card-hotline">
                <CardContent className="p-6 space-y-3">
                  <h4 className="font-semibold flex items-center gap-2 text-card-foreground">
                    <Phone className="h-5 w-5 text-primary" />
                    Đường Dây Nóng Hỗ Trợ Tâm Lý
                  </h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>• Tổng đài 1800 599 916 (Miễn phí)</p>
                    <p>• Đường dây nóng 028 3812 3456</p>
                    <p>• Hoạt động 24/7</p>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-resources">
                <CardContent className="p-6 space-y-3">
                  <h4 className="font-semibold flex items-center gap-2 text-card-foreground">
                    <Heart className="h-5 w-5 text-primary" />
                    Tài Nguyên Hỗ Trợ
                  </h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>• Bệnh viện Tâm thần TW1</p>
                    <p>• Viện Sức khỏe Tâm thần</p>
                    <p>• Tư vấn tâm lý trực tuyến</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <p className="text-center text-sm text-muted-foreground pt-6">
              © 2024 Sức Khỏe Tâm Lý. Được phát triển với mục đích hỗ trợ cộng đồng.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
