import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ThreeBackground } from "@/components/ThreeBackground";
import { type Answer, type AnalyzedResult } from "@shared/schema";
import { 
  calculateResults, 
  getSeverityLevelLabel, 
  getSeverityLevelColor,
  getSeverityBadgeVariant 
} from "@/lib/quizUtils";
import { AlertCircle, Heart, Phone, Home, TrendingUp, CheckCircle2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function ResultsPage() {
  const [, setLocation] = useLocation();
  const [result, setResult] = useState<AnalyzedResult | null>(null);
  const [showScore, setShowScore] = useState(false);

  useEffect(() => {
    const answersJson = localStorage.getItem('quizAnswers');
    if (!answersJson) {
      setLocation('/');
      return;
    }

    try {
      const answers: Answer[] = JSON.parse(answersJson);
      if (answers.length !== 18) {
        setLocation('/quiz');
        return;
      }

      const analyzedResult = calculateResults(answers);
      setResult(analyzedResult);

      setTimeout(() => setShowScore(true), 300);
    } catch (error) {
      console.error('Error parsing answers:', error);
      setLocation('/');
    }
  }, [setLocation]);

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full mx-auto" />
          <p className="text-muted-foreground">Đang phân tích kết quả...</p>
        </div>
      </div>
    );
  }

  const chartData = result.categoryScores.map(cat => ({
    name: cat.category,
    percentage: cat.percentage,
    fill: cat.percentage > 70 ? '#ef4444' : cat.percentage > 50 ? '#f59e0b' : '#10b981'
  }));

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5">
      <ThreeBackground />

      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-accent font-semibold text-foreground">
            Kết Quả Đánh Giá
          </h1>
          <ThemeToggle />
        </div>
      </header>

      <div className="pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-4xl space-y-8">
          <Card className="border-2 overflow-hidden">
            <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-8 md:p-12">
              <div className="text-center space-y-6">
                <div className="space-y-2">
                  <p className="text-sm uppercase tracking-wider text-muted-foreground font-medium">
                    Mức độ trầm cảm
                  </p>
                  <Badge 
                    variant={getSeverityBadgeVariant(result.severityLevel)}
                    className="text-lg px-6 py-2"
                    data-testid="severity-badge"
                  >
                    {getSeverityLevelLabel(result.severityLevel)}
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div className={`text-6xl md:text-7xl font-bold font-accent transition-all duration-1000 ${
                    showScore ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
                  } ${getSeverityLevelColor(result.severityLevel)}`}
                  data-testid="score-display">
                    {Math.round(result.percentage)}%
                  </div>
                  <p className="text-muted-foreground">
                    Điểm số: {result.totalScore} / {result.maxScore}
                  </p>
                </div>
              </div>
            </div>

            <CardContent className="p-8 md:p-12 space-y-6">
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <p className="text-lg text-foreground leading-relaxed">
                  {result.advice}
                </p>
              </div>

              {result.urgentHelp && (
                <div className="bg-destructive/10 border-2 border-destructive/30 rounded-xl p-6 space-y-4" data-testid="urgent-help-alert">
                  <div className="flex items-start gap-4">
                    <AlertCircle className="h-8 w-8 text-destructive flex-shrink-0 mt-1" />
                    <div className="space-y-3 flex-1">
                      <h3 className="text-xl font-semibold text-destructive">
                        Cần Hỗ Trợ Khẩn Cấp
                      </h3>
                      <p className="text-muted-foreground">
                        Kết quả cho thấy bạn đang cần sự hỗ trợ chuyên nghiệp. 
                        Vui lòng liên hệ ngay với các đường dây nóng dưới đây:
                      </p>
                      <div className="space-y-2 text-sm font-medium">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-destructive" />
                          <span>Đường dây nóng: 1800 599 916 (Miễn phí)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-destructive" />
                          <span>Tổng đài hỗ trợ: 028 3812 3456</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card data-testid="card-category-scores">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Phân Tích Chi Tiết
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {result.categoryScores.map((cat, index) => (
                  <div key={index} className="space-y-2" data-testid={`category-score-${index}`}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-card-foreground">{cat.category}</span>
                      <span className="text-muted-foreground">{Math.round(cat.percentage)}%</span>
                    </div>
                    <Progress value={cat.percentage} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card data-testid="card-chart">
              <CardHeader>
                <CardTitle>Biểu Đồ Phân Tích</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData} layout="vertical" margin={{ left: 20, right: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                    <XAxis type="number" domain={[0, 100]} />
                    <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                    <Tooltip 
                      formatter={(value: number) => `${Math.round(value)}%`}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="percentage" radius={[0, 4, 4, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card data-testid="card-recommendations">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-primary" />
                Những Bước Tiếp Theo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start gap-3 text-muted-foreground" data-testid={`recommendation-${index}`}>
                    <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-primary">{index + 1}</span>
                    </div>
                    <span className="flex-1">{rec}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20" data-testid="card-encouragement">
            <CardContent className="p-8 space-y-4">
              <div className="flex items-start gap-4">
                <Heart className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                <div className="space-y-3 flex-1">
                  <h3 className="text-xl font-semibold text-foreground">
                    Bạn Không Đơn Độc
                  </h3>
                  <p className="text-muted-foreground">
                    Hàng triệu người trên thế giới đang trải qua những khó khăn tương tự. 
                    Việc tìm kiếm sự giúp đỡ là dấu hiệu của sức mạnh, không phải sự yếu đuối. 
                    Có nhiều người và tài nguyên sẵn sàng hỗ trợ bạn.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
            <Link href="/">
              <Button variant="outline" size="lg" className="px-8" data-testid="button-home">
                <Home className="h-5 w-5 mr-2" />
                Về Trang Chủ
              </Button>
            </Link>
            <Link href="/quiz">
              <Button size="lg" className="px-8" data-testid="button-retake">
                Làm Lại Bài Test
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
