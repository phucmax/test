import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ThemeToggle } from "@/components/ThemeToggle";
import { questions, answerOptions, type Answer } from "@shared/schema";
import { ArrowLeft, ArrowRight } from "lucide-react";

const questionSchema = z.object({
  answer: z.string().min(1, "Vui lòng chọn một câu trả lời"),
});

type QuestionFormValues = z.infer<typeof questionSchema>;

export default function QuizPage() {
  const [, setLocation] = useLocation();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  const currentAnswer = answers.find(a => a.questionId === currentQuestion.id);

  const form = useForm<QuestionFormValues>({
    resolver: zodResolver(questionSchema),
    defaultValues: {
      answer: currentAnswer ? currentAnswer.value.toString() : "",
    },
  });

  useEffect(() => {
    const existingAnswer = answers.find(a => a.questionId === currentQuestion.id);
    form.reset({
      answer: existingAnswer ? existingAnswer.value.toString() : "",
    });
  }, [currentQuestionIndex, currentQuestion.id, answers, form]);

  const onSubmit = (data: QuestionFormValues) => {
    const answerValue = parseInt(data.answer);
    
    const updatedAnswers = answers.filter(a => a.questionId !== currentQuestion.id);
    updatedAnswers.push({ questionId: currentQuestion.id, value: answerValue });
    setAnswers(updatedAnswers);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      localStorage.setItem('quizAnswers', JSON.stringify(updatedAnswers));
      setLocation('/results');
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    } else {
      setLocation('/');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5">
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-accent font-semibold text-foreground">
            Đánh Giá Tâm Lý
          </h1>
          <ThemeToggle />
        </div>
      </header>

      <div className="pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-3xl">
          <div className="mb-8 space-y-3">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span data-testid="question-counter">Câu hỏi {currentQuestionIndex + 1} / {questions.length}</span>
              <span data-testid="progress-percentage">{Math.round(progress)}% hoàn thành</span>
            </div>
            <Progress value={progress} className="h-2" data-testid="progress-bar" />
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Card className="mb-8 border-2" data-testid={`question-card-${currentQuestion.id}`}>
                <CardContent className="p-8 md:p-12 space-y-8">
                  <div className="space-y-4">
                    <div className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
                      Câu {currentQuestionIndex + 1}
                    </div>
                    <h2 className="text-xl md:text-2xl font-medium text-foreground leading-relaxed" data-testid="question-text">
                      {currentQuestion.text}
                    </h2>
                  </div>

                  <FormField
                    control={form.control}
                    name="answer"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                            data-testid="answer-options"
                          >
                            {answerOptions.map((option) => (
                              <FormItem key={option.value}>
                                <FormLabel
                                  htmlFor={`option-${option.value}`}
                                  className={`
                                    flex items-center gap-4 p-5 rounded-xl border-2 cursor-pointer
                                    transition-all duration-200 hover-elevate
                                    ${field.value === option.value.toString()
                                      ? 'border-primary bg-primary/5'
                                      : 'border-border bg-card'
                                    }
                                  `}
                                  data-testid={`option-label-${option.value}`}
                                >
                                  <FormControl>
                                    <RadioGroupItem
                                      value={option.value.toString()}
                                      id={`option-${option.value}`}
                                      className="flex-shrink-0"
                                      data-testid={`radio-${option.value}`}
                                    />
                                  </FormControl>
                                  <span className="text-base md:text-lg text-card-foreground font-medium flex-1">
                                    {option.label}
                                  </span>
                                </FormLabel>
                              </FormItem>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <div className="flex items-center justify-between gap-4">
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  onClick={handleBack}
                  className="px-6"
                  data-testid="button-back"
                >
                  <ArrowLeft className="h-5 w-5 mr-2" />
                  {currentQuestionIndex === 0 ? 'Trang chủ' : 'Quay lại'}
                </Button>

                <Button
                  type="submit"
                  size="lg"
                  className="px-6"
                  disabled={!form.watch("answer")}
                  data-testid="button-next"
                >
                  {currentQuestionIndex === questions.length - 1 ? 'Xem kết quả' : 'Tiếp theo'}
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </div>

              {!form.watch("answer") && form.formState.isSubmitted && (
                <div className="text-center">
                  <p className="text-sm text-destructive">
                    Vui lòng chọn một câu trả lời để tiếp tục
                  </p>
                </div>
              )}
              
              <div className="mt-8 text-center">
                <p className="text-sm text-muted-foreground">
                  Hãy trả lời dựa trên cảm nhận của bạn trong 2 tuần gần đây
                </p>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
