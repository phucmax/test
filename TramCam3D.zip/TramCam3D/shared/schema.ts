import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const questions = [
  {
    id: 1,
    text: "Bạn có thường xuyên cảm thấy buồn chán hoặc chán nản không?",
    category: "mood"
  },
  {
    id: 2,
    text: "Bạn có mất hứng thú với những hoạt động mà trước đây bạn thích không?",
    category: "mood"
  },
  {
    id: 3,
    text: "Bạn có gặp khó khăn trong việc ngủ hoặc ngủ quá nhiều không?",
    category: "sleep"
  },
  {
    id: 4,
    text: "Bạn có cảm thấy mệt mỏi hoặc thiếu năng lượng không?",
    category: "energy"
  },
  {
    id: 5,
    text: "Bạn có thay đổi về cảm giác ngon miệng hoặc cân nặng không?",
    category: "appetite"
  },
  {
    id: 6,
    text: "Bạn có cảm thấy tự ti hoặc cảm thấy mình vô dụng không?",
    category: "self-esteem"
  },
  {
    id: 7,
    text: "Bạn có gặp khó khăn trong việc tập trung hoặc ra quyết định không?",
    category: "concentration"
  },
  {
    id: 8,
    text: "Bạn có di chuyển hoặc nói chuyện chậm hơn bình thường không?",
    category: "psychomotor"
  },
  {
    id: 9,
    text: "Bạn có suy nghĩ về cái chết hoặc tự tử không?",
    category: "suicidal"
  },
  {
    id: 10,
    text: "Bạn có cảm thấy bồn chồn hoặc lo lắng không?",
    category: "anxiety"
  },
  {
    id: 11,
    text: "Bạn có cảm thấy tội lỗi về những việc đã làm hoặc chưa làm không?",
    category: "guilt"
  },
  {
    id: 12,
    text: "Bạn có gặp khó khăn trong việc hoàn thành công việc hàng ngày không?",
    category: "daily-function"
  },
  {
    id: 13,
    text: "Bạn có tránh né giao tiếp xã hội hoặc cô lập bản thân không?",
    category: "social"
  },
  {
    id: 14,
    text: "Bạn có cảm thấy vô vọng về tương lai không?",
    category: "hopelessness"
  },
  {
    id: 15,
    text: "Bạn có đau đầu, đau lưng hoặc các vấn đề về cơ thể không rõ nguyên nhân không?",
    category: "physical"
  },
  {
    id: 16,
    text: "Bạn có khóc thường xuyên hoặc cảm thấy muốn khóc không?",
    category: "emotional"
  },
  {
    id: 17,
    text: "Bạn có cảm thấy cáu kỉnh hoặc dễ bực mình không?",
    category: "irritability"
  },
  {
    id: 18,
    text: "Bạn có cảm thấy trống rỗng hoặc vô cảm không?",
    category: "numbness"
  }
];

export const answerOptions = [
  { value: 0, label: "Không bao giờ", weight: 0 },
  { value: 1, label: "Thỉnh thoảng", weight: 1 },
  { value: 2, label: "Thường xuyên", weight: 2 },
  { value: 3, label: "Hầu như lúc nào", weight: 3 },
  { value: 4, label: "Luôn luôn", weight: 4 }
];

export const testResults = pgTable("test_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  answers: jsonb("answers").notNull(),
  totalScore: integer("total_score").notNull(),
  severityLevel: varchar("severity_level", { length: 50 }).notNull(),
  completedAt: varchar("completed_at").notNull(),
});

export const insertTestResultSchema = createInsertSchema(testResults).omit({
  id: true,
});

export type InsertTestResult = z.infer<typeof insertTestResultSchema>;
export type TestResult = typeof testResults.$inferSelect;

export type Answer = {
  questionId: number;
  value: number;
};

export type SeverityLevel = "minimal" | "mild" | "moderate" | "severe" | "very-severe";

export type CategoryScore = {
  category: string;
  score: number;
  maxScore: number;
  percentage: number;
};

export interface AnalyzedResult {
  totalScore: number;
  maxScore: number;
  percentage: number;
  severityLevel: SeverityLevel;
  categoryScores: CategoryScore[];
  advice: string;
  recommendations: string[];
  urgentHelp: boolean;
}
