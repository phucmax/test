import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTestResultSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/test-results", async (req, res) => {
    try {
      const validatedData = insertTestResultSchema.parse(req.body);
      const result = await storage.saveTestResult(validatedData);
      res.json(result);
    } catch (error) {
      console.error("Error saving test result:", error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Invalid data" 
      });
    }
  });

  app.get("/api/test-results/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const result = await storage.getTestResult(id);
      
      if (!result) {
        return res.status(404).json({ error: "Test result not found" });
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching test result:", error);
      res.status(500).json({ 
        error: "Failed to fetch test result" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
